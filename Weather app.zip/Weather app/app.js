const apiUrl= "https://api.openweathermap.org/data/2.5/weather?units=metric&q="
const apiKey = "0727efcd8c0583fa2828cea1acd8e9d9"

const scerchBox = document.querySelector(".search-box input");
const scerchBtn = document.querySelector(".search-box button");
const weatherImg = document.querySelector(".weather-img");

const chakWeather = async (city) =>{
    const response = await fetch(apiUrl+ city + `&appid=${apiKey}`);

if( response.status == 404) {
    document.querySelector(".error").style.display = "block"
    document.querySelector(".weather-body").style.display = "none"
}
else{
    let data = await response.json();
    // console.log(data)

    document.querySelector(".city").innerText =data.name;
    document.querySelector(".temper").innerText = Math.round(data.main.temp) + "°C";
    document.querySelector(".humadity").innerText =data.main.humidity + '%';
    document.querySelector(".wind").innerText =data.wind.speed + "km/h";
    
if ( data.weather[0].main =="Clouds" ){
    weatherImg.src = "clouds.png"
}
else if( data.weather[0].main =="Clear" ){
    weatherImg.src = "clear.png"
}
else if( data.weather[0].main =="Rain" ){
    weatherImg.src = "rain.png"
}
else if( data.weather[0].main =="Drizzle" ){
    weatherImg.src = "drizzle.png"
}
else if( data.weather[0].main =="Mist" ){
    weatherImg.src = "mist.png"
}

document.querySelector(".weather-body").style.display = "block"
document.querySelector(".error").style.display = "nune"

}   
}

scerchBtn.addEventListener("click", () =>{
    chakWeather(scerchBox.value);
})
 
 