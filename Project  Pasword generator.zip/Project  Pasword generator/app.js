const passwordBox = document.querySelector(".password");
const lenght = 12;
const upperCass ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowerCass = "abcdefghijklmnopqrstuvwxyz";
const number = "0123456789";
const symbol = "`!@#$%^&*()_+{}[]></|-=";
const allCharacter = upperCass + lowerCass + number + symbol;


function createPassword(){
    let password ="";
    password += upperCass[Math.floor(Math.random() * upperCass.length)];
    password += lowerCass[Math.floor(Math.random() * lowerCass.length)];
    password += number[Math.floor(Math.random() * number.length)];
    password += symbol[Math.floor(Math.random() * symbol.length)];

    while( lenght > password.length){
        password += allCharacter[Math.floor(Math.random() * allCharacter.length)];
    }
    passwordBox.value = password
}

function copyPassword(){
    passwordBox.select();
    document.execCommand("copy")

}